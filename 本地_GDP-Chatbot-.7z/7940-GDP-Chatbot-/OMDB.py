import requests

def get_movie_info(movieTitle):
    url = 'http://www.omdbapi.com/'
    api_key = '5e6f7556'
    data = {'apikey': api_key, 't': movieTitle}
    response = requests.get(url, data).json()

    return None if response.get("Response") != "True" else response
